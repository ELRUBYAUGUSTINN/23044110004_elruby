// home_screen.dart
import 'package:flutter/material.dart';
import '../models/transaksi.dart';
import '../services/api_service.dart';
import 'tambah_screen.dart';
import 'detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Transaksi> list = [];
  int saldo = 0;

  @override
  void initState() {
    super.initState();
    loadData();
  }

  void loadData() async {
    final data = await ApiService.fetchTransaksi();
    int total = 0;
    for (var t in data) {
      total += (t.jenis == 'Pemasukan') ? t.jumlah : -t.jumlah;
    }
    setState(() {
      list = data;
      saldo = total;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Saldo : Rp. $saldo', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.indigo)),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final t = list[i];
                  return Card(
                    color: Colors.teal.shade300,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      leading: Image.asset('assets/note.png'),
                      title: Text(t.title),
                      subtitle: Text('${t.jenis}\nTanggal : ${t.tanggal}'),
                      trailing: Text('Rp. ${t.jumlah}'),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(transaksi: t))),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.indigo.shade900,
        child: const Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => TambahScreen()));
          loadData();
        },
      ),
    );
  }
}
