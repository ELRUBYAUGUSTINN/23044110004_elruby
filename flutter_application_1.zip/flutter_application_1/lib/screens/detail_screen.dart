// detail_screen.dart
import 'package:flutter/material.dart';
import '../models/transaksi.dart';

class DetailScreen extends StatelessWidget {
  final Transaksi transaksi;

  const DetailScreen({super.key, required this.transaksi});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detail')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Image.asset('assets/note.png'),
          const SizedBox(height: 10),
          _infoTile('Title', transaksi.title),
          _infoTile('Jenis', transaksi.jenis),
          _infoTile('Tanggal', transaksi.tanggal),
          _infoTile('Jumlah', 'Rp. ${transaksi.jumlah}'),
          _infoTile('Deskripsi', transaksi.deskripsi),
          const SizedBox(height: 16),
          const Text('23-022 Lanny Aprilia', style: TextStyle(backgroundColor: Colors.indigo, color: Colors.white)),
        ]),
      ),
    );
  }

  Widget _infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        initialValue: value,
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.teal.shade300,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}
