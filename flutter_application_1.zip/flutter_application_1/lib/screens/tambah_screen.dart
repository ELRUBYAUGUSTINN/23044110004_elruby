// tambah_screen.dart
import 'package:flutter/material.dart';
import '../models/transaksi.dart';
import '../services/api_service.dart';

class TambahScreen extends StatefulWidget {
  const TambahScreen({super.key});

  @override
  State<TambahScreen> createState() => _TambahScreenState();
}

class _TambahScreenState extends State<TambahScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _tanggal = TextEditingController();
  final _jumlah = TextEditingController();
  final _deskripsi = TextEditingController();
  String _jenis = 'Pengeluaran';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Data')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(children: [
            Image.asset('assets/note.png'),
            const SizedBox(height: 10),
            TextFormField(controller: _title, decoration: _inputDecoration('Title')),
            const SizedBox(height: 10),
            DropdownButtonFormField(
              value: _jenis,
              decoration: _inputDecoration('Jenis'),
              items: const ['Pemasukan', 'Pengeluaran'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (val) => setState(() => _jenis = val!),
            ),
            const SizedBox(height: 10),
            TextFormField(controller: _tanggal, decoration: _inputDecoration('Tanggal')),
            const SizedBox(height: 10),
            TextFormField(controller: _jumlah, decoration: _inputDecoration('Jumlah'), keyboardType: TextInputType.number),
            const SizedBox(height: 10),
            TextFormField(controller: _deskripsi, decoration: _inputDecoration('Deskripsi'), maxLines: 3),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo.shade900),
              onPressed: () async {
                final t = Transaksi(
                  id: '',
                  title: _title.text,
                  jenis: _jenis,
                  tanggal: _tanggal.text,
                  jumlah: int.tryParse(_jumlah.text) ?? 0,
                  deskripsi: _deskripsi.text,
                );
                await ApiService.addTransaksi(t);
                Navigator.pop(context);
              },
              child: const Text('Simpan'),
            ),
          ]),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String label) => InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.teal.shade300,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      );
}
  