import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/transaksi.dart';

class ApiService {
  static const String baseUrl = 'https://transaksi-eb485-default-rtdb.firebaseio.com/';

  static Future<List<Transaksi>> fetchTransaksi() async {
    final res = await http.get(Uri.parse('$baseUrl/transaksi.json'));
    if (res.statusCode == 200) {
      final data = json.decode(res.body);
      if (data == null) return [];
      return (data as Map<String, dynamic>).entries.map((e) => Transaksi.fromJson(e.value, e.key)).toList();
    }
    return [];
  }

  static Future<void> addTransaksi(Transaksi trx) async {
    await http.post(Uri.parse('$baseUrl/transaksi.json'), body: json.encode(trx.toJson()));
  }

  static Future<void> deleteTransaksi(String id) async {
    await http.delete(Uri.parse('$baseUrl/transaksi/$id.json'));
  }

  static Future<void> updateTransaksi(Transaksi trx) async {
    await http.put(Uri.parse('$baseUrl/transaksi/${trx.id}.json'), body: json.encode(trx.toJson()));
  }
}
