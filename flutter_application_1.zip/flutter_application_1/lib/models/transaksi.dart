class Transaksi {
  String id;
  String title;
  String jenis; // Pemasukan / Pengeluaran
  String tanggal;
  int jumlah;
  String deskripsi;

  Transaksi({
    required this.id,
    required this.title,
    required this.jenis,
    required this.tanggal,
    required this.jumlah,
    required this.deskripsi,
  });

  factory Transaksi.fromJson(Map<String, dynamic> json, String id) {
    return Transaksi(
      id: id,
      title: json['title'],
      jenis: json['jenis'],
      tanggal: json['tanggal'],
      jumlah: json['jumlah'],
      deskripsi: json['deskripsi'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'jenis': jenis,
      'tanggal': tanggal,
      'jumlah': jumlah,
      'deskripsi': deskripsi,
    };
  }
}
